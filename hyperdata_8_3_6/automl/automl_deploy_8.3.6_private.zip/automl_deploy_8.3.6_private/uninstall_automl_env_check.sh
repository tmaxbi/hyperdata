if [ -z "$NAMESPACE" ]; then
  echo "Please set name \$NAMESPACE"
  exit 1
fi
