package cockroachdbrookio

const (
	GroupName = "cockroachdb.rook.io"
)
