#!/bin/bash
if [ -n "$1" ] ; then
SERVERNUM=$1
else
read -p "SERVER NUM :" SERVERNUM
fi
NS=hyperdata-dev$SERVERNUM

#kubectl get pod -n $NS -o wide
echo " "
echo "************************"
echo "om-0 boot.sh start"
echo "************************"
echo " "
kubectl exec -i om-0 -n $NS -- /bin/bash <<EOF
sh boot.sh
exit
EOF
sleep 10s
echo " "
echo "************************"
echo "datanode-0 boot.sh start"
echo "************************"
echo " "
kubectl exec -i datanode-0 -n $NS -- /bin/bash <<EOF
sh boot.sh
exit
EOF
sleep 10s
echo " "
echo "************************"
echo "datanode-1 boot.sh start"
echo "************************"
echo " "
kubectl exec -i datanode-1 -n $NS -- /bin/bash <<EOF
sh boot.sh
exit
EOF
sleep 10s
echo " "
echo "************************"
echo "datanode-2 boot.sh start"
echo "************************"
echo " "
kubectl exec -i datanode-2 -n $NS -- /bin/bash <<EOF
sh boot.sh
exit
EOF

